Project YOU v10 — quieter language
- Removed “worldwide”
- Hero now says “A collaborative music project”
- Softened institutional / charity-campaign language
- Preserved the music-first, intimate editorial tone
- Existing v9 visual design and artist credits preserved

- Updated children-related wording from “conflict” to “war or conflict” throughout.
